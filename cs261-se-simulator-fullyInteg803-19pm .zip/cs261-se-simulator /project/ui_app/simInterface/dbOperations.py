from flask import Flask, request, jsonify
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv
import os
from datetime import datetime
import json
from conf.logConfig import get_logger
import subprocess

from simInterface.connectionManager import getDbConnection

logger = get_logger(__name__)


def load_Junction(data):
    logger.info("load_Junction()")
    conn = getDbConnection()
    if conn:

        # data = load_json_data(vph_json_file_path)
        # logger.info(data)
        if data:

            newJid = insert_Junction(conn, data)

        conn.close()
    return newJid


def load_layouts(jid, data):
    logger.info("load_layouts()")
    conn = getDbConnection()
    new_jlids = []
    if conn:

        # data = load_json_data(layout_json_file_path)

        for layout in data:
            logger.info(layout)
            if layout:

                new_jlid = insert_layouts(conn, jid, layout)
                new_jlids.append(new_jlid)
                logger.info(f"new new_jlids = {new_jlids}")
        conn.close()
    return new_jlids


def insert_layouts(conn, jid, data):
    logger.info("insert_layouts()")
    new_jlid = -1
    try:
        cur = conn.cursor()

        # Extract relevant fields
        # jid = data.get("junctionId")
        config_object = json.dumps(data)
        jl_state_id = 1  # You need to specify the JLStateID

        # Insert into table
        cur.execute(
            """
            INSERT INTO junction_layouts (JID, ConfigurationObject, JLStateID)
            VALUES (%s, %s::jsonb, %s)
            RETURNING JLID
        """,
            (jid, config_object, jl_state_id),
        )
        # Fetch the newly created JLID

        new_jlid = cur.fetchone()[0]
        logger.info(f" NEW JLID inserted {new_jlid} ")
        conn.commit()
        logger.info("Layout Data inserted successfully.")
    except psycopg2.Error as e:
        logger.info(f"Failed to insert layout data: {e}")
        conn.rollback()
    finally:
        if cur:
            cur.close()
    return new_jlid


def insert_Junction(conn, data):
    logger.info("insert_Junction()")
    new_jid = -1
    try:
        cur = conn.cursor()

        # Extract relevant fields
        uid = data.get("userId")
        jname = data.get("jName")
        vph_object = json.dumps(data)
        j_state_id = 1  # You need to specify the JStateID
        # created_date = datetime.now()

        # Insert into table
        cur.execute(
            """
            INSERT INTO junctions (UID, JName, VPHObject, JStateID)
            VALUES (%s, %s, %s::jsonb, %s)
            RETURNING JID
        """,
            (uid, jname, vph_object, j_state_id),
        )
        # Fetch the newly created JID

        # logger.info(f" before fetc hing one ---------")
        new_jid = cur.fetchone()[0]

        # logger.info(f" after fetc hing one ---------")

        conn.commit()
        logger.info("Junction inserted successfully.")
    except psycopg2.Error as e:
        logger.info(f"Failed to insert data: {e}")
        conn.rollback()
    finally:
        if cur:
            cur.close()
    return new_jid


def changeLayoutState(jid, jlid, jlstateid):
    logger.info(
        f" simulation job state to be changed to {jlstateid} in simulator.py jid = {jid} , jlid = {jlid}"
    )
    conn = getDbConnection()

    logger.info(f" conn = {conn}")
    cur = conn.cursor()

    # Retrieve the junction data
    cur.execute(
        "SELECT ConfigurationObject FROM junction_layouts WHERE jlid = %s and jid = %s",
        (jlid, jid),
    )
    result = cur.fetchone()

    if result:
        configurationObject = result[0]
        # print(f"Simulating with JID: {jid}, JLID: {jlid}")
        # print(f"Junction Layout Config data: {configurationObject}")

        # Update the flag to show job is ready to be dispatched to simulator
        cur.execute(
            "UPDATE junction_layouts SET jlstateid = %s WHERE jlid = %s",
            (
                jlstateid,
                jlid,
            ),
        )
        conn.commit()
    else:
        logger.info(f"No junction found with ID: {jlid}")

    cur.close()
    conn.close()
