from flask import Flask, request, jsonify, current_app
import httpx
from simInterface.dbOperations import changeLayoutState
from tenacity import retry, stop_after_attempt, wait_fixed

import os
from dotenv import load_dotenv


from conf.logConfig import setup_logging, get_logger

# Set up logging
setup_logging()


logger = get_logger(__name__)  # Create a logger instance


load_dotenv()

API_BASE_URL = os.getenv("API_BASE_URL", "http://nginx/api")


@retry(stop=stop_after_attempt(3), wait=wait_fixed(2))
async def makeApiCall(client, url):
    logger.info(f"make_request()")
    logger.info(f"url = {url}")
    response = await client.get(url)
    response.raise_for_status()
    return response


async def initiateSimulation(jid, jlid):
    logger.info("log - initiateSimulation()")

    async with httpx.AsyncClient(timeout=2.0) as client:
        try:
            changeLayoutState(jid, jlid, 2)
            url = f"{API_BASE_URL}/simulate?jid={jid}&jlid={jlid}"

            response = await makeApiCall(client, url)

            return (
                jsonify(
                    {"message": "Simulation triggered", "result :": response.json()}
                ),
                202,
            )
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error occurred: {e}")
            return (
                jsonify({"error": f"HTTP error occurred: {str(e)}"}),
                e.response.status_code,
            )
        except Exception as e:
            logger.error(f"Error occurred: {e}")
            return jsonify({"error": f"Error occurred: {str(e)}"}), 500
