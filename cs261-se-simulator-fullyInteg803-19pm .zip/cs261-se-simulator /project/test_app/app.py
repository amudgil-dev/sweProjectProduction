from flask import Flask, request, jsonify, current_app

from dotenv import load_dotenv

from conf.logConfig import setup_logging, get_logger
from bizLogic.junctionDataManager import loadJunctionAndLayout, reset_layout_state

# Set up logging
setup_logging()

logger = get_logger(__name__)  # Create a logger instance

app = Flask(__name__)

load_dotenv()


@app.route("/resetlayout", methods=["GET"])
async def resetLayout():
    logger.info(f"loadtestjunction()")
    jid = request.args.get("jid")
    jlid = request.args.get("jlid")
    try:
        reset_layout_state(jid, jlid)
        return (
            jsonify(
                {
                    "message": "Successfully reset layout",
                    "data": {"junction_id": jid, "layout_ids": jlid},
                }
            ),
            200,
        )
    except Exception as e:
        logger.info(f"Error occurred while resetting layout: {str(e)}")
        return (
            jsonify(
                {
                    "error": f"Error occurred while resetting layout : {str(e)}",
                    "data": {"junction_id": None, "layout_id": []},
                }
            ),
            500,
        )


@app.route("/loadtestjunction", methods=["GET"])
async def loadtestjunction():
    logger.info(f"loadtestjunction()")

    try:
        new_jid, new_jlids = loadJunctionAndLayout()
        return (
            jsonify(
                {
                    "message": "Successfully loaded junction and layouts",
                    "data": {"junction_id": new_jid, "layout_ids": new_jlids},
                }
            ),
            200,
        )
    except Exception as e:
        logger.info(f"Error occurred while loading data: {str(e)}")
        return (
            jsonify(
                {
                    "error": f"Error occurred while loading data: {str(e)}",
                    "data": {"junction_id": None, "layout_ids": []},
                }
            ),
            500,
        )


@app.route("/", methods=["GET"])
@app.route("/health", methods=["GET"])
async def health_check():
    logger.info(f"checking health")
    return (
        jsonify({"message": "HEALTH IS OKAY of Test App !!"}),
        200,
    )


if __name__ == "__main__":
    logger.info(f"main starting()")
    app.run(host="0.0.0.0", debug=True, port=8000)
