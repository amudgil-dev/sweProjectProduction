import json

# import psycopg2
from db.dbOperations import changeLayoutState, load_Junction, load_layouts
from datetime import datetime
from conf.logConfig import setup_logging, get_logger


logger = get_logger(__name__)  # Create a logger instance


# JSON file path
# layout_json_file_path = "testdata/layout_data.json"
# vph_json_file_path = "testdata/vph_data.json"
vph_json_file_path = "testdata/vph_data_v3.json"
layout_json_file_path = "testdata/layout_data_v3.json"


def read_json_data_from_file(file_path):
    logger.info(f"load_json_data(read_json_data_from_file = {file_path})")
    try:
        with open(file_path, "r") as file:
            data = json.load(file)
            return data
    except FileNotFoundError:
        logger.info("JSON file not found.")
        return None
    except json.JSONDecodeError:
        logger.info(f"Failed to parse JSON from teh file = {file_path}")
        return None


def loadJunctionAndLayout():
    logger.info("loadJunctionAndLayout()")
    new_jid = -1
    new_jlids = []
    try:
        vph_data = read_json_data_from_file(vph_json_file_path)

        logger.info(f" vph_data = {vph_data} ")

        layout_data = read_json_data_from_file(layout_json_file_path)

        logger.info(f" layout_data = {layout_data} ")

        if vph_data == None or layout_data == None:
            return new_jid, new_jlids

        new_jid = load_Junction(vph_data)

        logger.info(f" new_jid inserted = {new_jid}")
        new_jlids = load_layouts(new_jid, layout_data)
        return new_jid, new_jlids
    except Exception as e:
        logger.info(f"Exception occured - {str(e)}")
        return new_jid, new_jlids


def reset_layout_state(jid, jlid):
    changeLayoutState(jid, jlid, 1)
