from flask import Flask, request, jsonify
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv
import os

from conf.logConfig import get_logger
import subprocess

logger = get_logger(__name__)

load_dotenv()  # This loads the variables from .env file


def getDbConnection():
    logger.info("getDbConnection()")
    # print("111")
    # host = os.environ["DB_HOST"]
    # print("222")
    # print(f" host = {host}")
    return psycopg2.connect(
        host=os.environ["DB_HOST"],
        database=os.environ["DB_NAME"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
    )
