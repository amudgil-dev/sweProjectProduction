docker compose up -d --scale ui_app=3 --scale simulation_app=2 --scale test_app=1

