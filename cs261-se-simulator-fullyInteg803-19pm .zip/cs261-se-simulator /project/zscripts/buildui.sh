docker compose build --no-cache ui_app1 ui_app2 ui_app3
docker compose up -d --no-deps --force-recreate ui_app1 ui_app2 ui_app3 
