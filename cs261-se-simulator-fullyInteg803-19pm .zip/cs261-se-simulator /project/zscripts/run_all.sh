docker compose up --build -d 
