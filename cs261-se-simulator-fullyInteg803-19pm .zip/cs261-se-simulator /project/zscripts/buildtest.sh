docker compose build --no-cache test_app
docker compose up -d --no-deps --force-recreate test_app