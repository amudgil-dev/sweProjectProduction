docker compose build --no-cache simulator_api1 
docker compose up -d --no-deps --force-recreate simulator_api1 
