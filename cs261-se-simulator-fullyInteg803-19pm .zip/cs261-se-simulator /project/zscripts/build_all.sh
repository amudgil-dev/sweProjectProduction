docker compose build 

