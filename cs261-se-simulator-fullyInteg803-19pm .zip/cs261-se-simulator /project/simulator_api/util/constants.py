# class JLJobStates:
#     JOB_PASSED_TO_SIM = 2
#     JOB_ACCEPTED_BY_SIM = 3
#     JOB_COMPLETED = 4
#     JOB_FAILED = 5

#     def __setattr__(self, name, value):
#         raise AttributeError("Constants are immutable")
