import json
from typing import List, NamedTuple
from dataclasses import dataclass
from enum import Enum, auto
from mapperVPHObject import VPHData
from mapperLayoutObject import JunctionLayout, LaneType, LaneMap, Arm
from db.connectionManager import getDbConnection

# from project.simulator_api.zzz_managerDatabase import get_db_connection
from simulatorCore.conf.logConfig import get_logger
from db.dbOperations import JLJobStates, readJobPayloads

logger = get_logger(__name__)


class IngestionManager:

    def ingestInputs(self, jid, jlid):
        logger.info(f"ingestInputs()")
        # pull data from the database
        vph_data, jlayout_data = readJobPayloads(jid, jlid)

        # modify the lane types in layout data to expected format 'busLane' => 'bus'
        modified_jlayout_data = modify_lane_types(jlayout_data)

        # transform json to objects
        vphObj = VPHData.vphJsonToObj(vph_data)
        # layoutObj = JunctionLayout.layoutJsonToObj(jlayout_data)
        layoutObj = JunctionLayout.layoutJsonToObj(modified_jlayout_data)

        return vphObj, layoutObj


def readVphLayoutDataFromDb(jid, jlid):
    logger.info(f"readVphLayoutDataFromDb()")
    im = IngestionManager()
    return im.ingestInputs(jid, jlid)


def modify_lane_types(data):
    # Define the replacements
    replacements = {"busLane": "bus", "cycleLane": "cycle"}

    # Recursively replace the lane types
    def replace_lane_types(data):
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, str) and value in replacements:
                    data[key] = replacements[value]
                else:
                    replace_lane_types(value)
        elif isinstance(data, list):
            for item in data:
                replace_lane_types(item)

    replace_lane_types(data)

    return data
