from collections import namedtuple
from enum import Enum, auto
from typing import List, NamedTuple
from dataclasses import dataclass
from simulatorCore.conf.logConfig import get_logger

# initialise logger
logger = get_logger(__name__)

# define named tuples for VPH & vehicle ratio data
VPH = namedtuple("VPH", ["total", "left", "straight", "right"])
VehicleRatio = namedtuple("VehicleRatio", ["car", "bus", "cycle"])


# class to define lane types
class LaneTypeDef:
    def __init__(self):
        # vph going left should be distributed amongst the lane types in the set
        self.left = ("leftOnly", "leftStraight", "allDirs")
        # vph going straight should be distributed amonst the lane types in the set
        self.straight = ("leftStraight", "rightStraight", "straightOnly", "allDirs")
        self.right = ("rightOnly", "rightStraight", "allDirs")
        self.special = ("bus", "cycle")


# Enum class to define lane types
class LaneType(Enum):
    bus = auto()
    leftOnly = auto()
    straightOnly = auto()
    rightOnly = auto()
    leftStraight = auto()
    rightStraight = auto()
    allDirs = auto()
    cycle = auto()


# laneMap tuple keeps lanes mapped with thier IDs
# ensure output of ManagerDistributer is in correct format
class LaneMap(NamedTuple):
    laneId: str
    laneType: LaneType


# Dataclass to represent a junction arm with lanes and pedestrian crossing info
@dataclass
class Arm:
    lanes: List[LaneMap]
    pedestrianCrossing: bool
    laneCount: int


class TrafficDistributor:
    def __init__(self, vphObj, junctionLayoutObj, laneTypeObj):
        self.vphObj = vphObj
        self.junctionLayoutObj = junctionLayoutObj
        self.laneTypeObj = laneTypeObj
        self.assignedVPH = {}

    def initiateVphAllocationToLanes(self):
        for arm in ("northArm", "eastArm", "southArm", "westArm"):
            self.assignedVPH[arm] = self.allocationAlgorithm(arm)
            logger.info(self.assignedVPH)
        return self.assignedVPH

    def allocationAlgorithm(self, arm):
        logger.info(f"------------------ {arm} --------------------------")
        vph, ratio = getattr(self.vphObj, arm)
        arm_obj = getattr(self.junctionLayoutObj, arm)
        lanes = arm_obj.lanes
        assigned = {}

        logger.info(f"VPH: {vph}")
        logger.info(f"Ratio: {ratio}")
        logger.info(f"Lanes: {lanes}")

        special_lane_assignment = {}

        if lanes and (
            lanes[0].laneType.value in {LaneType.bus.value, LaneType.cycle.value}
        ):
            logger.info(f" IF SPECIAL LANE ({lanes[0].laneType.name}) IS TRUE -----")
            vph, special_lane_assignment[lanes[0].laneId] = self.handleSpecialLane(
                lanes[0].laneType, vph, ratio
            )
            lanes = lanes[1:]

        leftLanes = [lane for lane in lanes if self.isLeftLane(lane.laneType)]
        straightLanes = [lane for lane in lanes if self.isStraightLane(lane.laneType)]
        rightLanes = [lane for lane in lanes if self.isRightLane(lane.laneType)]

        logger.info(f"{arm}:")
        # print("left", leftLanes)
        # print("straight", straightLanes)
        # print("right", rightLanes)

        logger.info(f"Distributing left VPH: {vph.left}")
        distributeLeft = self.distributeVPH(vph.left, leftLanes)
        logger.info(f"Left distribution: {distributeLeft}")

        logger.info(f"Distributing straight VPH: {vph.straight}")
        distributeStraight = self.distributeVPH(vph.straight, straightLanes)
        logger.info(f"Straight distribution: {distributeStraight}")

        logger.info(f"Distributing right VPH: {vph.right}")
        distributeRight = self.distributeVPH(vph.right, rightLanes)
        logger.info(f"Right distribution: {distributeRight}")

        for distribution in (distributeLeft, distributeStraight, distributeRight):
            for k, v in distribution.items():
                assigned[k] = assigned.get(k, 0) + v

        assigned.update(special_lane_assignment)
        logger.info(f"Assigned: {assigned}")
        return assigned

    def handleSpecialLane(self, laneType, vph, ratio):
        if laneType.value == LaneType.bus.value:
            specialRatio = ratio.bus
        elif laneType.value == LaneType.cycle.value:
            specialRatio = ratio.cycle
        else:
            return vph, 0

        specialVPH = VPH(*(int(v * specialRatio / 100) for v in vph))
        remainingVPH = VPH(*(v - s for v, s in zip(vph, specialVPH)))
        specialVPH = specialVPH[0]

        return remainingVPH, specialVPH

    def distributeVPH(self, vph, lanes):
        if not lanes:
            return {}
        if len(lanes) == 1:
            return {lanes[0].laneId: vph}

        dedicated = [lane for lane in lanes if self.isDedicatedLane(lane.laneType)]
        shared = [lane for lane in lanes if not self.isDedicatedLane(lane.laneType)]

        assigned = {}

        if dedicated:
            dedicatedVPH = int(vph * 0.7)
            for lane in dedicated:
                assigned[lane.laneId] = dedicatedVPH // len(dedicated)

            remainingVPH = vph - dedicatedVPH

            if shared:
                for lane in shared:
                    assigned[lane.laneId] = remainingVPH // len(shared)
        else:
            for lane in lanes:
                assigned[lane.laneId] = vph // len(lanes)

        # Ensure all VPH is distributed
        total_assigned = sum(assigned.values())
        if total_assigned < vph:
            remaining = vph - total_assigned
            for lane in lanes:
                assigned[lane.laneId] += remaining // len(lanes)

        return assigned

    @staticmethod
    def isLeftLane(laneType):
        # print(f"Checking left lane: {laneType}")
        return laneType.value in {
            LaneType.leftOnly.value,
            LaneType.leftStraight.value,
            LaneType.allDirs.value,
        }

    @staticmethod
    def isStraightLane(laneType):
        # print(f"Checking straight lane: {laneType}")
        return laneType.value in {
            LaneType.straightOnly.value,
            LaneType.leftStraight.value,
            LaneType.rightStraight.value,
            LaneType.allDirs.value,
        }

    @staticmethod
    def isRightLane(laneType):
        # print(f"Checking right lane: {laneType}")
        return laneType.value in {
            LaneType.rightOnly.value,
            LaneType.rightStraight.value,
            LaneType.allDirs.value,
        }

    @staticmethod
    def isDedicatedLane(laneType):
        return laneType.value in (
            LaneType.leftOnly.value,
            LaneType.straightOnly.value,
            LaneType.rightOnly.value,
        )


def convert_to_traffic_flows_map(assigned_vph, junction_layout):
    logger.info("Converting the finaloutput to traffic flows")

    logger.info(f"assigned_vph => \n{assigned_vph}")

    logger.info(f"junction_layout => \n{junction_layout}")

    traffic_flows_map = {}
    for arm in assigned_vph:
        traffic_flows_map[arm] = {}
        arm_lanes = getattr(junction_layout, arm).lanes
        for lane in arm_lanes:
            if lane.laneId in assigned_vph[arm]:
                traffic_flows_map[arm][lane.laneId] = (
                    lane.laneType.name,
                    assigned_vph[arm][lane.laneId],
                )
    logger.info(f"traffic_flows_map = {traffic_flows_map}")
    return traffic_flows_map
