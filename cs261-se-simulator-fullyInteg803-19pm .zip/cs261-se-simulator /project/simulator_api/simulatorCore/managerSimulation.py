import simpy
from enum import Enum
import collections
import random
from collections import namedtuple
from abc import ABC, abstractmethod
import json

from simulatorCore.conf.logConfig import get_logger, setup_logging

setup_logging()
logger = get_logger(__name__)

CarRecord = namedtuple("CarRecord", ["car", "arrivalTime"])

# Local variables and counters
lastPedCrossing = 0
pedReq = False

# From layout
pedCrossing = False

# From VPH
pedcrph = 10
pedCrossingDur = 10


def initialisePedVars(vphObj, layoutObj):
    print("initialisePedVars()")
    global pedCrossing, pedcrph, pedCrossingDur
    pedCrossing = layoutObj.pedFlag
    pedcrph = vphObj.pedRq
    pedCrossingDur = vphObj.pedDur


class LightControlStrategy(ABC):
    @abstractmethod
    def run_lights(self, env, light_control):
        pass


class DefaultLightStrategy(LightControlStrategy):
    def run_lights(self):
        pass


class PedestrianLightStrategy(LightControlStrategy):
    def run_lights(self):
        pass


class SpecialLaneLightStrategy(LightControlStrategy):
    def run_lights(self):
        pass


class RightFilterLightStrategy(LightControlStrategy):
    def run_lights(self):
        pass


class LightControl:
    def __init__(self, env):
        logger.info(f"-------------- initialised LightControl -----------")
        self.env = env
        self.phaseCount = 0
        self.red_ns_subs = []
        self.red_nsSpecial_subs = []
        self.red_ew_subs = []
        self.red_ewSpecial_subs = []
        self.green_ns_subs = []
        self.green_nsSpecial_subs = []
        self.green_ew_subs = []
        self.green_ewSpecial_subs = []
        self.env.process(self.run_lights())

        if pedCrossing and pedcrph > 0:
            self.env.process(generatePedReq(env))

    def _broadcast(self, subscribers):
        for callback in subscribers:
            callback()

    def run_lights(self):
        logger.info(f"-------------- run_lights -----------")
        while True:
            self.phaseCount += 1
            global pedReq, lastPedCrossing
            if (
                pedCrossing
                and pedcrph > 0
                and pedReq
                and (self.phaseCount - lastPedCrossing >= 2)
            ):
                logger.info(f"{self.env.now} All red for pedestrian crossing")
                yield self.env.timeout(pedCrossingDur)
                pedReq = False
                lastPedCrossing = self.phaseCount
                logger.info(f"{self.env.now} Pedestrian crossing complete")

            logger.info("a")

            if len(self.green_nsSpecial_subs) > 0:
                self._broadcast(self.green_nsSpecial_subs)
                logger.info(f"{self.env.now} ns special is green")
                yield self.env.timeout(30)
                self._broadcast(self.red_nsSpecial_subs)
            logger.info("b")

            self._broadcast(self.green_ns_subs)
            logger.info(f"{self.env.now} ns is green")

            yield self.env.timeout(40)
            self._broadcast(self.red_ns_subs)
            if len(self.green_ewSpecial_subs) > 0:
                self._broadcast(self.green_ewSpecial_subs)
                logger.info(f"{self.env.now} ns special is green")
                yield self.env.timeout(30)
                self._broadcast(self.red_ewSpecial_subs)
            self._broadcast(self.green_ew_subs)
            logger.info(f"{self.env.now} ew is green")
            yield self.env.timeout(40)
            self._broadcast(self.red_ew_subs)
            if self.phaseCount > 1000:
                self.phaseCount = 0


class VehicleType(Enum):
    CAR = 1
    BUS = 2
    CYCLE = 3


class LaneType(Enum):
    LEFTONLY = 1
    RIGHTONLY = 2
    STRAIGHTONLY = 3
    LEFTSTRAIGHT = 4
    RIGHTSTRAIGHT = 5
    ALLDIRS = 6


class Lane:
    def __init__(self, env, name, dir, vehicleType, laneType):
        logger.info("lane clase init")
        logger.info(f"-------------- initialised Lane -----------")
        self.env = env
        self.name = name
        self.dir = dir
        self.vehicleType = vehicleType
        self.laneType = laneType
        self.laneQueue = collections.deque()
        self.green = False
        self.passingTime = {
            LaneType.LEFTONLY: 3,
            LaneType.LEFTSTRAIGHT: 3.5,
            LaneType.STRAIGHTONLY: 4,
            LaneType.RIGHTSTRAIGHT: 6,
            LaneType.RIGHTONLY: 10,
            VehicleType.BUS: 10,
            VehicleType.CYCLE: 10,
        }
        self.maxQueueLength = 0
        self.maxWaitTime = 0.0
        self.totalWaitTime = 0.0
        self.carsProcessed = 0

    def addCar(self, car):
        self.laneQueue.append(CarRecord(car=car, arrivalTime=self.env.now))
        self.maxQueueLength = max(self.maxQueueLength, len(self.laneQueue))

    def moveCars(self):
        while self.green and self.laneQueue:
            carData = self.laneQueue.popleft()
            waitTime = self.env.now - carData.arrivalTime
            self.totalWaitTime += waitTime
            self.carsProcessed += 1
            self.maxWaitTime = max(self.maxWaitTime, waitTime)
            passingTime = self.passingTime.get(self.laneType, 5)
            yield self.env.timeout(passingTime)
            logger.info(f"{self.env.now} {self.name} car has left junction")

    def green_light(self):
        self.green = True
        self.env.process(self.moveCars())

    def red_light(self):
        self.green = False


def generateCars(env, lane, delayFunction):
    logger.info("generateCars()")

    while True:
        yield env.timeout(delayFunction())
        lane.addCar(object())


def calculateDelay(flowRate):
    logger.info(f"calculating flow rate => {flowRate} ")
    return lambda: random.expovariate(flowRate / 3600)


def generatePedReq(env):
    while True:
        yield env.timeout(random.expovariate(pedcrph / 3600))
        global pedReq

        logger.info(f"pedcrph in genPeREq => {pedcrph} ")

        pedReq = True
        logger.info(f"{env.now} Pedestrian request received")


def startSimulation(traffic_flows_map, vphObj, layoutObj):
    logger.info("in startSimulation() ")
    initialisePedVars(vphObj, layoutObj)
    env = simpy.Environment()
    lights = LightControl(env)

    logger.info(f"env =>{env}")

    lanes = {}

    logger.info("creating lanes ")

    for direction, lane_data in traffic_flows_map.items():
        lanes[direction] = {}
        for lane_name, (lane_type, flow) in lane_data.items():
            full_lane_name = f"{direction}_{lane_name}"
            vehicle_type = (
                VehicleType.BUS
                if lane_type == "bus"
                else VehicleType.CYCLE if lane_type == "cycle" else VehicleType.CAR
            )
            lane_type_enum = (
                LaneType[lane_type.upper()]
                if lane_type.upper() in LaneType.__members__
                else LaneType.STRAIGHTONLY
            )
            lane = Lane(env, full_lane_name, direction, vehicle_type, lane_type_enum)
            lanes[direction][lane_name] = lane
            if direction in ["north", "south"]:
                if vehicle_type in [VehicleType.BUS, VehicleType.CYCLE]:
                    lights.green_nsSpecial_subs.append(lane.green_light)
                    lights.red_nsSpecial_subs.append(lane.red_light)
                else:
                    lights.green_ns_subs.append(lane.green_light)
                    lights.red_ns_subs.append(lane.red_light)
            else:
                if vehicle_type in [VehicleType.BUS, VehicleType.CYCLE]:
                    lights.green_ewSpecial_subs.append(lane.green_light)
                    lights.red_ewSpecial_subs.append(lane.red_light)
                else:
                    lights.green_ew_subs.append(lane.green_light)
                    lights.red_ew_subs.append(lane.red_light)
    for direction, lane_data in traffic_flows_map.items():
        for lane_name, (lane_type, flow) in lane_data.items():
            lane = lanes[direction][lane_name]

            logger.info(f"starting the car gen process for lane => {lane_name} ")

            env.process(generateCars(env, lane, calculateDelay(flow)))
    env.run(18000)
    logger.info("\nFinal queue lengths:")
    for direction, lane_data in lanes.items():
        for lane_name, lane in lane_data.items():
            averageWaitTime = (
                lane.totalWaitTime / lane.carsProcessed if lane.carsProcessed > 0 else 0
            )
            logger.info(f"Lane {lane.name}: ({direction}, {lane_name}): ")
            logger.info(f"  Average wait time: {averageWaitTime:.2f}s")
            logger.info(f"  Maximum wait time: {lane.maxWaitTime:.2f}s")
            logger.info(f"  Maximum queue length: {lane.maxQueueLength} vehicles")
    logger.info("---------------------------------")
    logger.info("final json")
    logger.info("---------------------------------")
    # Prepare the output dictionary
    output = {
        "status": "simulation completed successfully",
        "northArm": {"laneStats": {}},
        "eastArm": {"laneStats": {}},
        "southArm": {"laneStats": {}},
        "westArm": {"laneStats": {}},
    }
    # Populate the output dictionary
    for direction, lane_data in lanes.items():
        arm_name = direction if direction.endswith("Arm") else f"{direction}Arm"
        for lane_name, lane in lane_data.items():
            average_wait_time = (
                lane.totalWaitTime / lane.carsProcessed if lane.carsProcessed > 0 else 0
            )
            output[arm_name]["laneStats"][lane_name] = {
                "average wait time": round(average_wait_time, 2),
                "max wait time": round(lane.maxWaitTime, 2),
                "max queue length": lane.maxQueueLength,
            }
    logger.info(json.dumps(output, indent=4))
    return output


# traffic_flows_map = {
#     "northArm": {
#         "lane1": ("bus", 30),
#         "lane2": ("leftOnly", 45),
#         "lane3": ("rightOnly", 90),
#         "lane4": ("straightOnly", 135),
#     },
#     "eastArm": {
#         "lane1": ("leftStraight", 32),
#         "lane2": ("rightStraight", 32),
#         "lane3": ("straightOnly", 35),
#     },
#     "southArm": {"lane1": ("leftOnly", 25), "lane2": ("rightStraight", 75)},
#     "westArm": {
#         "lane1": ("leftOnly", 50),
#         "lane2": ("rightOnly", 50),
#         "lane3": ("straightOnly", 100),
#     },
# }

# startSimulation(traffic_flows_map)
