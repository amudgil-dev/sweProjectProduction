import os
import psycopg2
import traceback
import time
import sys
import json
from dotenv import load_dotenv
from pathlib import Path
from managerIngestion import readVphLayoutDataFromDb
from managerDistribution import (
    TrafficDistributor,
    LaneTypeDef,
    convert_to_traffic_flows_map,
)
from managerSimulation import startSimulation
from simulatorCore.conf.logConfig import get_logger
from db.dbOperations import changeLayoutState, storeSimulationResults, JLJobStates

# from util.constants import JLbStates


# setup_logging()
logger = get_logger(__name__)

# Get the path to the .env
current_dir = Path(__file__).resolve().parent
env_path = current_dir / ".env"


def executeSimulator(jid, jlid):
    logger.info(f" executeSimulator() ")
    logger.info("----- READING vph and layout Object from DB -----\n")
    vphObj, layoutObj = readVphLayoutDataFromDb(jid, jlid)

    logger.info(f" vphObj= \t {vphObj} \n")
    logger.info(f" layoutObj= \t {layoutObj}")
    lane_type_def = LaneTypeDef()

    logger.info("\n----- Distributing traffic to lanes -----")

    distributor = TrafficDistributor(vphObj, layoutObj, lane_type_def)
    assigned_vph = distributor.initiateVphAllocationToLanes()
    logger.info("            ")
    logger.info("Final Assigned VPH:", assigned_vph)

    logger.info("\n----- Distributing to lanes completed -----")

    # Assuming you have your JunctionLayout object named 'layout'
    traffic_flows_map = convert_to_traffic_flows_map(assigned_vph, layoutObj)

    logger.info("---- TRANSFORMING Payload to feed to simulator ------")
    logger.info("traffic_flows_map:", traffic_flows_map)
    logger.info("----- TRAFFIC FLOW MAPS GENERATED | Starting Simulation-----\n")
    layout_results = startSimulation(traffic_flows_map, vphObj, layoutObj)
    logger.info("\n----- SIMULATION RESULTS -----")
    logger.info(f"simulation_results = {layout_results}")
    logger.info("\n-----------------------")
    return layout_results


def workflow(jid, jlid):
    logger.info(f" workflow() ")
    try:

        changeLayoutState(
            jid, jlid, JLJobStates.JOB_ACCEPTED_BY_SIM
        )  # changing the job state to 'Accepted' by simulator
        logger.info("job for jid = {jid} and jlid = {jlid} accepted ")

        logger.info("------- EXECUTING SIMULATOR NOW --- ")
        layout_results = executeSimulator(jid, jlid)

        storeSimulationResults(jlid, layout_results)
        logger.info("------- SIMULATION RESULTS STORED --- ")
        changeLayoutState(
            jid, jlid, JLJobStates.JOB_COMPLETED
        )  # changing the job state to 'Completed' by simulator
        logger.info("changed job status for jlid")
        return "success"
    except Exception as e:
        msg = f"Simulation for this jid {jid} and jlid {jlid} failed: {str(e)}"
        logger.error(msg)
        storeSimulationResults(
            jlid,
            {
                "status": f"Simulation for this jid {jid} and jlid {jlid} failed: {str(e)}"
            },
        )
        changeLayoutState(
            jid, jlid, JLJobStates.JOB_FAILED
        )  # changing the job state to 'Failed' by simulator

        return None


def triggerSimulatorWorkflow():
    logger.info("triggerSimulatorWorkflow() ")
    # time.sleep(0)

    if len(sys.argv) != 3:
        logger.error("Usage: python simulator.py <jid> <jlid>")

    else:
        try:
            jid = int(sys.argv[1])
            jlid = int(sys.argv[2])

            result = workflow(jid, jlid)
            if result is None:
                raise ValueError("Exception Occured")
            else:
                return result
        except Exception as e:
            msg = f"Simulation for this jid {jid} and jlid {jlid} failed: {str(e)}"
            logger.error(msg)
            return msg


if __name__ == "__main__":

    # For testing purpose
    # runSimulatorIndependently()

    logger.info("triggering triggerSimulatorWorkflow() ")
    triggerSimulatorWorkflow()
    logger.info("completed triggerSimulatorWorkflow() ")

    # results = {"status": "success"}
    # jlid = 10
    # store_simulation_results(jlid, results)
