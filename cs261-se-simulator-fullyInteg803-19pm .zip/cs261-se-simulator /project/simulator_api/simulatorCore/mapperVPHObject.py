import json
from collections import namedtuple
from simulatorCore.conf.logConfig import get_logger


logger = get_logger(__name__)

VPH = namedtuple("VPH", ["total", "left", "straight", "right"])
VehicleRatio = namedtuple("VehicleRatio", ["car", "bus", "cycle"])

direction_mapping = {
    "northArm": {"left": "east", "straight": "south", "right": "west"},
    "eastArm": {"left": "south", "straight": "west", "right": "north"},
    "southArm": {"left": "west", "straight": "north", "right": "east"},
    "westArm": {"left": "north", "straight": "east", "right": "south"},
}


class VPHData:
    def __init__(self):
        self.pedRq = 0
        self.pedDur = 0.0
        self.northArm = None
        self.eastArm = None
        self.southArm = None
        self.westArm = None
        self.priorities = {}

    def __repr__(self):
        return (
            f"VPHData(pedRq={self.pedRq}, pedDur={self.pedDur}, "
            f"northArm={self.northArm}, eastArm={self.eastArm}, "
            f"southArm={self.southArm}, westArm={self.westArm}, "
            f"priorities={self.priorities})"
        )

    @classmethod
    def vphJsonToObj(cls, data):
        logger.info("vphJsonToObj() in mapperVPHObject")
        vphObj = VPHData()

        vphObj.pedDur = data["pedestrianCrossingDuration"]

        for direction in ["northArm", "eastArm", "southArm", "westArm"]:
            flow = data["trafficFlows"][direction]

            # picking the highest value of pedestrianCrossingRph & pedestrianCrossingDuration across all arms
            # Update max values if current arm has higher values
            vphObj.pedRq = max(vphObj.pedRq, flow.get("pedestrianCrossingRph", 0))
            # vphObj.pedDur = max(
            #     vphObj.pedDur, flow.get("pedestrianCrossingDuration", 0)
            # )

            # Store priority for each arm
            vphObj.priorities[direction] = flow.get("priority", 0)

            vph = VPH(
                total=flow["totalVph"],
                left=flow["exitingVph"].get(direction_mapping[direction]["left"], 0),
                straight=flow["exitingVph"].get(
                    direction_mapping[direction]["straight"], 0
                ),
                right=flow["exitingVph"].get(direction_mapping[direction]["right"], 0),
            )
            vehicle_ratio = VehicleRatio(
                car=flow["vehicleSplit"].get("car", 0),
                bus=flow["vehicleSplit"].get("bus", 0),
                cycle=flow["vehicleSplit"].get("cycle", 0),
            )

            setattr(vphObj, direction, (vph, vehicle_ratio))

        return vphObj
