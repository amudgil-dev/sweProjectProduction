import json
from typing import List, NamedTuple
from dataclasses import dataclass
from enum import Enum, auto
from simulatorCore.conf.logConfig import get_logger

logger = get_logger(__name__)


class LaneType(Enum):
    bus = auto()
    leftOnly = auto()
    straightOnly = auto()
    rightOnly = auto()
    leftStraight = auto()
    rightStraight = auto()
    allDirs = auto()


class LaneMap(NamedTuple):
    laneId: str
    laneType: LaneType


@dataclass
class Arm:
    lanes: List[LaneMap]
    pedestrianCrossing: bool
    laneCount: int


class JunctionLayout:
    def __init__(self, jLayoutName: str, timestamp: str, userId: int, junctionId: int):
        self.jLayoutName = jLayoutName
        self.timestamp = timestamp
        self.userId = userId
        self.junctionId = junctionId
        self.northArm = Arm([], False, 0)
        self.eastArm = Arm([], False, 0)
        self.southArm = Arm([], False, 0)
        self.westArm = Arm([], False, 0)
        self.pedFlag = False

    def add_lane(self, direction: str, lane_id: str, lane_type: str):
        arm = getattr(self, f"{direction}Arm")
        arm.lanes.append(LaneMap(lane_id, LaneType[lane_type]))

    def set_arm_data(self, direction: str, pedestrian_crossing: bool, lane_count: int):
        arm = getattr(self, f"{direction}Arm")
        arm.pedestrianCrossing = pedestrian_crossing
        arm.laneCount = lane_count

    def __repr__(self):
        return (
            f"{self.__class__.__name__}("
            f"jLayoutName={self.jLayoutName!r}, "
            f"timestamp={self.timestamp!r}, "
            f"userId={self.userId!r}, "
            f"junctionId={self.junctionId!r}, "
            f"northArm={self.northArm!r}, "
            f"eastArm={self.eastArm!r}, "
            f"southArm={self.southArm!r}, "
            f"westArm={self.westArm!r}), "
            f"pedFlag={self.pedFlag!r})"
        )

    @classmethod
    def layoutJsonToObj(cls, data):
        logger.info("layoutJsonToObj() in mapperLayoutObject")
        layout = JunctionLayout(
            data["jLayoutName"], data["timestamp"], data["userId"], data["junctionId"]
        )

        for direction in ["north", "east", "south", "west"]:

            arm_data = data[f"{direction}Arm"]
            layout.set_arm_data(
                direction, arm_data["pedestrianCrossing"], arm_data["laneCount"]
            )
            if arm_data["pedestrianCrossing"] == True:
                layout.pedFlag = True

            for lane_id, lane_type in arm_data["laneDetail"].items():
                layout.add_lane(direction, lane_id, lane_type)

        return layout
