import subprocess
import json
import os
from flask import jsonify
from conf.logConfig import get_logger
from db.dbOperations import isJobValid

logger = get_logger(__name__)


import json


def invokeSimulation(jid, jlid):
    # check if the job has not already been accepted look for status JOB_PASSED_TO_SIM
    if isJobValid(jid, jlid) == False:

        logger.warning(
            f"Record for layout jid={jid} and jlid={jlid} either does not exist or may not be in the correct state!"
        )
        return {
            "status": "failed",
            "message": f"Record for layout jid={jid} and jlid={jlid} either does not exist or may not be in the correct state!",
        }
    else:
        return _invokeAsynchronously(jid, jlid)


""" 
    This method is invoking the sub process in sync mode and 
    opening a bi-directional pipe to read the print statements in the simulator line by line
    and waits for the process to end.
"""


def _invokeSynchronously(jid, jlid):
    logger.info(f"invokeSynchronously ({jid}, {jlid})")

    simulator_script = "/app/simulatorCore/simulatorApp.py"
    python_executable = "python"

    cmd = [python_executable, simulator_script, str(jid), str(jlid)]

    try:
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd="/app",
            text=True,
            bufsize=1,
            universal_newlines=True,
        )

        output = []
        for line in process.stdout:
            print(line, end="")  # Print to console in real-time
            output.append(line)

        process.wait()

        if process.returncode == 0:
            logger.info(
                f"Simulation completed successfully! Return code: {process.returncode}"
            )
            return {"status": "success", "message": "".join(output)}
        else:
            stderr_output = process.stderr.read()
            logger.error(f"Simulation failed! Return code: {process.returncode}")
            logger.error(f"Error output: {stderr_output}")
            return {
                "status": "failed",
                "message": f"Error (return code {process.returncode}): {stderr_output}",
            }

    except Exception as e:
        logger.error(f"An error occurred while running the simulation: {str(e)}")
        return {"status": "failed", "message": f"Exception occurred: {str(e)}"}


"""
    This method invokes the simulator in Async mode.
"""


def _invokeAsynchronously(jid, jlid):
    logger.info(f"invokeAsynchronously ({jid}, {jlid})")

    simulator_script = simulator_script = "/app/simulatorCore/simulatorApp.py"
    python_executable = "python"

    cmd = [python_executable, simulator_script, str(jid), str(jlid)]

    try:
        process = subprocess.Popen(
            cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd="/app"
        )
        logger.info(f"Simulation process started with PID: {process.pid}")

        # Optionally, you can log the output for debugging
        stdout, stderr = process.communicate(timeout=5)
        if stdout:
            logger.info(f"Simulation output: {stdout.decode()}")
        if stderr:
            logger.error(f"Simulation error: {stderr.decode()}")

        return {
            "status": "success",
            "message": f"Simulation started with PID: {process.pid}",
        }
    except subprocess.TimeoutExpired:
        logger.info(f"Simulation process started but didn't complete within timeout.")
        return {
            "status": "success",
            "message": f"Simulation started with PID: {process.pid} (non-blocking)",
        }
    except Exception as e:
        logger.error(f"Failed to start simulation: {str(e)}")
        return {"status": "failed", "message": str(e)}
