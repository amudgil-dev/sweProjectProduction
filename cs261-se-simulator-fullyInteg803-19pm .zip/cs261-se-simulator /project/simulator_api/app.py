from flask import Flask, request, jsonify
import asyncio
import socket
import os
from dotenv import load_dotenv
from bizLogic.triggerManager import invokeSimulation

from conf.logConfig import setup_logging, get_logger


# Set up logging
setup_logging()

# Get a logger for this module
logger = get_logger(__name__)

app = Flask(__name__)


@app.route("/", methods=["GET"])
async def home():
    print(" print sim app.py - home()")
    logger.info("sim app.py - home()")
    # logger.info("\n".join(result))
    # print("\n".join(result))
    # changeLayoutState(jid, jlid, 4)
    result = "successful"
    return jsonify({"message": "Home Route  completed", "result": result}), 200


@app.route("/simulate", methods=["GET"])
def simulate():
    logger.info("simulate/")
    jid = request.args.get("jid")
    jlid = request.args.get("jlid")

    if not jid or not jlid:
        return jsonify({"error": "Both jid and jlid are required"}), 400

    try:
        return invokeSimulation(jid, jlid)
    except Exception as e:
        logger.error(f"error caught in simulate() : str(e)")
        return jsonify({"error caught in simulate() ": str(e)}), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True, port=8000)
