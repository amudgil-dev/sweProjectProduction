# from flask import Flask, request, jsonify
import psycopg2
from psycopg2.extras import RealDictCursor
from dotenv import load_dotenv
import os
import json
from conf.logConfig import get_logger
import subprocess
import time
import sys
from psycopg2 import OperationalError
from pathlib import Path
from db.connectionManager import getDbConnection


logger = get_logger(__name__)

load_dotenv()  # This loads the variables from .env file


class JLJobStates:
    JOB_PASSED_TO_SIM = 2
    JOB_ACCEPTED_BY_SIM = 3
    JOB_COMPLETED = 4
    JOB_FAILED = 5

    def __setattr__(self, name, value):
        raise AttributeError("Constants are immutable")


def isJobValid(jid, jlid):
    logger.info(f" isJobValid( jid = {jid} , jlid = {jlid})")

    conn = getDbConnection()

    print(f" conn = {conn}")
    cur = conn.cursor()

    # Retrieve the junction data
    logger.info(f"JOB_ACCEPTED_BY_SIM = {JLJobStates.JOB_PASSED_TO_SIM}")
    cur.execute(
        "SELECT 1 FROM junction_layouts WHERE jlid = %s and jid = %s and jlstateid <= %s",
        (jlid, jid, JLJobStates.JOB_PASSED_TO_SIM),
    )
    result = cur.fetchone()
    acceptable = False
    if result:
        # data = result[0]
        logger.info(f"JOB IS ACCEPTABLE with JID: {jid}, JLID: {jlid}")
        acceptable = True

    else:
        logger.warning(
            f"JOB IS NOT ACCEPTABLE with JID: {jid}, JLID: {jlid}, jlstateid not correct"
        )

    cur.close()
    conn.close()
    return acceptable


def readJobPayloads(jid, jlid):
    logger.info(f" readJobPayloads( jid = {jid} , jlid = {jlid})")

    vph_data = {}
    jlayout_data = {}

    conn = getDbConnection()

    print(f" conn = {conn}")
    cur = conn.cursor()

    # Retrieve the junction data
    logger.info(f"JOB_ACCEPTED_BY_SIM = {JLJobStates.JOB_ACCEPTED_BY_SIM}")
    cur.execute(
        "SELECT ConfigurationObject FROM junction_layouts WHERE jlid = %s and jid = %s and jlstateid = %s",
        (jlid, jid, JLJobStates.JOB_ACCEPTED_BY_SIM),
    )
    layout_result = cur.fetchone()

    if layout_result:
        jlayout_data = layout_result[0]
        print(f"Simulating with JID: {jid}, JLID: {jlid}")
        print(f"Junction Layout Config data: {jlayout_data}")

        # Execute a second query
        cur.execute("SELECT vphobject FROM junctions WHERE jid = %s", (jid,))
        vph_result = cur.fetchone()

        if vph_result:
            vph_data = vph_result[0]
            # logger.info(f"vph_data : {vph_data}")
        else:
            logger.error(f"No junction found with ID: {jid}")

    else:
        logger.error(f"No junction Layout found with ID: {jlid}")

    cur.close()
    conn.close()

    return vph_data, jlayout_data


def changeLayoutState(jid, jlid, jlstateid):
    logger.info(
        f" simulation job state to be changed to {jlstateid} in simulator.py jid = {jid} , jlid = {jlid}"
    )
    conn = getDbConnection()

    logger.info(f" conn = {conn}")
    cur = conn.cursor()

    # Retrieve the junction data
    cur.execute(
        "SELECT ConfigurationObject FROM junction_layouts WHERE jlid = %s and jid = %s",
        (jlid, jid),
    )
    result = cur.fetchone()

    if result:
        configurationObject = result[0]
        # print(f"Simulating with JID: {jid}, JLID: {jlid}")
        # print(f"Junction Layout Config data: {configurationObject}")

        # Update the flag to show job is accepted by simulator
        cur.execute(
            "UPDATE junction_layouts SET jlstateid = %s WHERE jlid = %s",
            (
                jlstateid,
                jlid,
            ),
        )
        conn.commit()
    else:
        logger.info(f"No junction layout found with JLID: {jlid}")

    cur.close()
    conn.close()


def storeSimulationResults(jlid, results_json):
    conn = getDbConnection()
    cur = conn.cursor()

    try:
        cur.execute(
            "INSERT INTO simulation_results (JLID, ResultsObject) VALUES (%s, %s)",
            (jlid, json.dumps(results_json)),
        )
        conn.commit()
        logger.info(f"Simulation results stored for JLID: {jlid}")
    except Exception as e:
        conn.rollback()
        logger.error(f"Error storing simulation results: {str(e)}")
    finally:
        cur.close()
        conn.close()
