#!/bin/bash

# Create the main project directory
mkdir -p project

# Create the directory structure and empty files
cd project
touch docker-compose.yml

mkdir -p nginx
touch nginx/Dockerfile nginx/nginx.conf

mkdir -p ui_app
touch ui_app/Dockerfile ui_app/app.py

mkdir -p simulator_api
touch simulator_api/Dockerfile simulator_api/app.py

echo "Project structure created successfully."

echo "Creating the log directories"
mkdir -p logs/ui_app1 logs/ui_app2 logs/ui_app3 logs/simulator_api1 logs/simulator_api2 logs/simulator_api3 logs/test_app
