import logging
import os, sys
from pathlib import Path


# def setup_logging():
#     # Define the log directory
#     log_dir = Path("logs/")

#     # Create the directory if it doesn't exist
#     log_dir.mkdir(parents=True, exist_ok=True)

#     # Define the log file path
#     log_file = log_dir / "simulator_app.log"

#     logging.basicConfig(
#         level=logging.INFO,
#         format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
#         filename=str(log_file),
#         filemode="a",
#     )


def setup_logging():
    # Get container hostname for unique log files when scaling
    hostname = os.environ.get("HOSTNAME", "unknown")

    # Define the log directory
    log_dir = Path("/app/logs/")

    # Create the directory if it doesn't exist
    log_dir.mkdir(parents=True, exist_ok=True)

    # Define the log file path with container hostname
    log_file = log_dir / f"test_app-{hostname}.log"

    # Create a formatter with function name included
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s - %(message)s"
    )

    # Set up file handler
    file_handler = logging.FileHandler(str(log_file), mode="a")
    file_handler.setFormatter(formatter)

    # Set up stream handler for stdout (for Docker logging)
    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(formatter)

    # Configure the root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    root_logger.addHandler(file_handler)
    root_logger.addHandler(stream_handler)


def get_logger(name=None):
    """
    Returns a logger instance. If no name is provided, returns the root logger.
    """
    return logging.getLogger(name)
