import json
from collections import namedtuple
from simulatorCore.conf.logConfig import get_logger

# Initialize logger for this module
logger = get_logger(__name__)

# Define named tuples for structured data representation
# VPH: Vehicles Per Hour with breakdown by turning movement
VPH = namedtuple("VPH", ["total", "left", "straight", "right"])
# VehicleRatio: Distribution of vehicle types
VehicleRatio = namedtuple("VehicleRatio", ["car", "bus", "cycle"])

# Mapping dictionary that defines the relationship between approach directions and exit directions
# For each approach (e.g., northArm), specifies where left/straight/right movements lead
direction_mapping = {
    "northArm": {"left": "east", "straight": "south", "right": "west"},
    "eastArm": {"left": "south", "straight": "west", "right": "north"},
    "southArm": {"left": "west", "straight": "north", "right": "east"},
    "westArm": {"left": "north", "straight": "east", "right": "south"},
}


class VPHData:
    """
    Class to store and process vehicle per hour data for traffic simulation.
    Contains traffic flow information for all intersection approaches and pedestrian data.
    """

    def __init__(self):
        # Initialize pedestrian request rate and duration
        self.pedRq = 0
        self.pedDur = 0.0
        # Initialize approach arms (will be populated with VPH and VehicleRatio tuples)
        self.northArm = None
        self.eastArm = None
        self.southArm = None
        self.westArm = None
        # Dictionary to store priority values for each approach
        self.priorities = {}

    def __repr__(self):
        """
        String representation of the VPHData object for debugging and logging
        """
        return (
            f"VPHData(pedRq={self.pedRq}, pedDur={self.pedDur}, "
            f"northArm={self.northArm}, eastArm={self.eastArm}, "
            f"southArm={self.southArm}, westArm={self.westArm}, "
            f"priorities={self.priorities})"
        )

    @classmethod
    def vphJsonToObj(cls, data):
        """
        Class method to convert JSON traffic flow data into a VPHData object

        Args:
            data: Dictionary containing traffic flow data from JSON

        Returns:
            VPHData: Populated object with traffic flow information
        """
        logger.info("vphJsonToObj() in mapperVPHObject")
        vphObj = VPHData()

        # Set pedestrian crossing duration from input data
        vphObj.pedDur = data["pedestrianCrossingDuration"]

        # Process each approach arm (north, east, south, west)
        for direction in ["northArm", "eastArm", "southArm", "westArm"]:
            flow = data["trafficFlows"][direction]

            # Find the maximum pedestrian crossing request rate across all arms
            vphObj.pedRq = max(vphObj.pedRq, flow.get("pedestrianCrossingRph", 0))

            # Store priority value for this approach
            vphObj.priorities[direction] = flow.get("priority", 0)

            # Create VPH tuple with total flow and breakdown by turning movement
            # Uses direction_mapping to translate from approach to exit direction
            vph = VPH(
                total=flow["totalVph"],
                left=flow["exitingVph"].get(direction_mapping[direction]["left"], 0),
                straight=flow["exitingVph"].get(
                    direction_mapping[direction]["straight"], 0
                ),
                right=flow["exitingVph"].get(direction_mapping[direction]["right"], 0),
            )

            # Create VehicleRatio tuple with distribution of vehicle types
            vehicle_ratio = VehicleRatio(
                car=flow["vehicleSplit"].get("car", 0),
                bus=flow["vehicleSplit"].get("bus", 0),
                cycle=flow["vehicleSplit"].get("cycle", 0),
            )

            # Set the appropriate attribute on the VPHData object
            # Each arm stores a tuple of (VPH, VehicleRatio)
            setattr(vphObj, direction, (vph, vehicle_ratio))

        return vphObj
