# Import necessary libraries
import json
from typing import List, NamedTuple  # For type hinting
from dataclasses import dataclass  # For creating data classes with less boilerplate
from enum import Enum, auto  # For creating enumeration types
from simulatorCore.conf.logConfig import get_logger  # Import logging configuration

# Initialize logger for this module
logger = get_logger(__name__)


# Enumeration of possible lane types in a traffic junction
class LaneType(Enum):

    bus = auto()  # Bus-only lane
    leftOnly = auto()  # Left-turn only lane
    straightOnly = auto()  # Straight-only lane
    rightOnly = auto()  # Right-turn only lane
    leftStraight = auto()  # Lane allowing left turns and straight movement
    rightStraight = auto()  # Lane allowing right turns and straight movement
    allDirs = auto()  # Lane allowing all directions


# Named tuple to associate a lane ID with its type
class LaneMap(NamedTuple):

    laneId: str  # Unique identifier for the lane
    laneType: LaneType  # Type of the lane (from LaneType enum)


# Represents one arm (approach) of a junction
@dataclass
class Arm:

    lanes: List[LaneMap]  # List of lanes in this arm
    pedestrianCrossing: bool  # Whether this arm has a pedestrian crossing
    laneCount: int  # Total number of lanes in this arm


"""
The JunctionLayout class models a four-way traffic junction (intersection) 
with arms extending in the north, east, south, and west directions. 
Each arm can have multiple lanes with different permitted movements, and may include pedestrian crossings.
"""


class JunctionLayout:
    def __init__(self, jLayoutName: str, timestamp: str, userId: int, junctionId: int):
        # Initialize junction layout with metadata
        self.jLayoutName = jLayoutName  # Name of the junction layout
        self.timestamp = timestamp  # Timestamp when the layout was created/modified
        self.userId = userId  # ID of the user who created/owns the layout
        self.junctionId = junctionId  # Unique identifier for the junction

        # Initialize the four arms of the junction with default values
        self.northArm = Arm([], False, 0)
        self.eastArm = Arm([], False, 0)
        self.southArm = Arm([], False, 0)
        self.westArm = Arm([], False, 0)

        # Flag to indicate if any pedestrian crossings exist in the junction
        self.pedFlag = False

    def add_lane(self, direction: str, lane_id: str, lane_type: str):
        # Add a lane to a specific arm
        arm = getattr(
            self, f"{direction}Arm"
        )  # Dynamically access the arm based on direction
        arm.lanes.append(
            LaneMap(lane_id, LaneType[lane_type])
        )  # Add the lane with its type

    def set_arm_data(self, direction: str, pedestrian_crossing: bool, lane_count: int):
        # Set pedestrian crossing and lane count for a specific arm
        arm = getattr(
            self, f"{direction}Arm"
        )  # Dynamically access the arm based on direction
        arm.pedestrianCrossing = pedestrian_crossing
        arm.laneCount = lane_count

    def __repr__(self):
        # Provide a detailed string representation of the junction layout
        return (
            f"{self.__class__.__name__}("
            f"jLayoutName={self.jLayoutName!r}, "
            f"timestamp={self.timestamp!r}, "
            f"userId={self.userId!r}, "
            f"junctionId={self.junctionId!r}, "
            f"northArm={self.northArm!r}, "
            f"eastArm={self.eastArm!r}, "
            f"southArm={self.southArm!r}, "
            f"westArm={self.westArm!r}), "
            f"pedFlag={self.pedFlag!r})"
        )

    @classmethod
    def layoutJsonToObj(cls, data):
        # Class method to create a JunctionLayout object from JSON data
        logger.info("layoutJsonToObj() in mapperLayoutObject")

        # Create a new JunctionLayout with basic metadata
        layout = JunctionLayout(
            data["jLayoutName"], data["timestamp"], data["userId"], data["junctionId"]
        )

        # Process each arm (north, east, south, west)
        for direction in ["north", "east", "south", "west"]:
            # Get the arm data from the JSON
            arm_data = data[f"{direction}Arm"]

            # Set the arm's properties
            layout.set_arm_data(
                direction, arm_data["pedestrianCrossing"], arm_data["laneCount"]
            )

            # Update the pedestrian flag if this arm has a pedestrian crossing
            if arm_data["pedestrianCrossing"] == True:
                layout.pedFlag = True

            # Add each lane to the arm
            for lane_id, lane_type in arm_data["laneDetail"].items():
                layout.add_lane(direction, lane_id, lane_type)

        return layout
