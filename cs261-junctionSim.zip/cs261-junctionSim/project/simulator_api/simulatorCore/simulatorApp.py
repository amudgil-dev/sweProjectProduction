# import os
# import psycopg2  # PostgreSQL database adapter
# import traceback
# import time
import sys

# import json
from dotenv import load_dotenv  # For loading environment variables
from pathlib import Path  # For handling file paths

# Import custom modules for data ingestion
from managerIngestion import readVphLayoutDataFromDb

# Import traffic distribution related modules
from managerDistribution import (
    TrafficDistributor,
    LaneTypeDef,
    convert_to_traffic_flows_map,
)

# Import simulation module
from managerSimulation import startSimulation

# Import logging configuration
from simulatorCore.conf.logConfig import get_logger

# Import database operations
from db.dbOperations import changeLayoutState, storeSimulationResults, JLJobStates

# Initialize logger for this module
logger = get_logger(__name__)

# Get the path to the .env file for environment variables
current_dir = Path(__file__).resolve().parent
env_path = current_dir / ".env"


def executeSimulator(jid, jlid):
    """
    Execute the traffic simulation for a given job ID and job layout ID.

    Args:
        jid (int): Job ID
        jlid (int): Job Layout ID

    Returns:
        dict: Simulation results
    """
    logger.info(f" executeSimulator() ")
    logger.info("----- READING vph and layout Object from DB -----\n")
    # Retrieve vehicle per hour and layout data from database
    vphObj, layoutObj = readVphLayoutDataFromDb(jid, jlid)

    logger.info(f" vphObj= \t {vphObj} \n")
    logger.info(f" layoutObj= \t {layoutObj}")
    # Initialize lane type definitions
    lane_type_def = LaneTypeDef()

    logger.info("\n----- Distributing traffic to lanes -----")

    # Create traffic distributor and allocate vehicles to lanes
    distributor = TrafficDistributor(vphObj, layoutObj, lane_type_def)
    assigned_vph = distributor.initiateVphAllocationToLanes()
    logger.info("            ")
    logger.info("Final Assigned VPH:", assigned_vph)

    logger.info("\n----- Distributing to lanes completed -----")

    # Convert assigned VPH to traffic flow map format required by simulator
    traffic_flows_map = convert_to_traffic_flows_map(assigned_vph, layoutObj)

    logger.info("---- TRANSFORMING Payload to feed to simulator ------")
    logger.info("traffic_flows_map:", traffic_flows_map)
    logger.info("----- TRAFFIC FLOW MAPS GENERATED | Starting Simulation-----\n")

    # Start the actual simulation with the prepared data
    layout_results = startSimulation(traffic_flows_map, vphObj, layoutObj)
    logger.info("\n----- SIMULATION RESULTS -----")
    logger.info(f"simulation_results = {layout_results}")
    logger.info("\n-----------------------")
    return layout_results


def workflow(jid, jlid):
    """
    Execute the complete simulation workflow including state management.

    Args:
        jid (int): Job ID
        jlid (int): Job Layout ID

    Returns:
        str: "success" if workflow completes successfully, None otherwise
    """
    logger.info(f" workflow() ")
    try:
        # Update job state to indicate simulation has started
        changeLayoutState(
            jid, jlid, JLJobStates.JOB_ACCEPTED_BY_SIM
        )  # changing the job state to 'Accepted' by simulator
        logger.info("job for jid = {jid} and jlid = {jlid} accepted ")

        logger.info("------- EXECUTING SIMULATOR NOW --- ")
        # Run the simulation
        layout_results = executeSimulator(jid, jlid)

        # Store simulation results in database
        storeSimulationResults(jlid, layout_results)
        logger.info("------- SIMULATION RESULTS STORED --- ")

        # Update job state to completed
        changeLayoutState(
            jid, jlid, JLJobStates.JOB_COMPLETED
        )  # changing the job state to 'Completed' by simulator
        logger.info("changed job status for jlid")
        return "success"
    except Exception as e:
        # Handle any exceptions during simulation
        msg = f"Simulation for this jid {jid} and jlid {jlid} failed: {str(e)}"
        logger.error(msg)

        # Store error information in database
        storeSimulationResults(
            jlid,
            {
                "status": f"Simulation for this jid {jid} and jlid {jlid} failed: {str(e)}"
            },
        )

        # Update job state to failed
        changeLayoutState(
            jid, jlid, JLJobStates.JOB_FAILED
        )  # changing the job state to 'Failed' by simulator

        return None


def triggerSimulatorWorkflow():
    """
    Entry point function to trigger the simulation workflow.
    Expects command line arguments for job ID and job layout ID.

    Returns:
        str: Result message or error message
    """
    logger.info("triggerSimulatorWorkflow() ")

    # Validate command line arguments
    if len(sys.argv) != 3:
        logger.error("Usage: python simulator.py <jid> <jlid>")
    else:
        try:
            # Parse job ID and job layout ID from command line arguments
            jid = int(sys.argv[1])
            jlid = int(sys.argv[2])

            # Execute the workflow
            result = workflow(jid, jlid)
            if result is None:
                raise ValueError("Exception Occured")
            else:
                return result
        except Exception as e:
            # Handle any exceptions during workflow execution
            msg = f"Simulation for this jid {jid} and jlid {jlid} failed: {str(e)}"
            logger.error(msg)
            return msg


# Script entry point
if __name__ == "__main__":
    logger.info("triggering triggerSimulatorWorkflow() ")
    # Start the simulation workflow
    triggerSimulatorWorkflow()
    logger.info("completed triggerSimulatorWorkflow() ")
# Import necessary libraries
import os
import psycopg2  # PostgreSQL database adapter
import traceback
import time
import sys
import json
from dotenv import load_dotenv  # For loading environment variables
from pathlib import Path  # For handling file paths

# Import custom modules for data ingestion
from managerIngestion import readVphLayoutDataFromDb

# Import traffic distribution related modules
from managerDistribution import (
    TrafficDistributor,
    LaneTypeDef,
    convert_to_traffic_flows_map,
)

# Import simulation module
from managerSimulation import startSimulation

# Import logging configuration
from simulatorCore.conf.logConfig import get_logger

# Import database operations
from db.dbOperations import changeLayoutState, storeSimulationResults, JLJobStates

# Initialize logger for this module
logger = get_logger(__name__)

# Get the path to the .env file for environment variables
current_dir = Path(__file__).resolve().parent
env_path = current_dir / ".env"


def executeSimulator(jid, jlid):
    """
    Execute the traffic simulation for a given job ID and job layout ID.

    Args:
        jid (int): Job ID
        jlid (int): Job Layout ID

    Returns:
        dict: Simulation results
    """
    logger.info(f" executeSimulator() ")
    logger.info("----- READING vph and layout Object from DB -----\n")
    # Retrieve vehicle per hour and layout data from database
    vphObj, layoutObj = readVphLayoutDataFromDb(jid, jlid)

    logger.info(f" vphObj= \t {vphObj} \n")
    logger.info(f" layoutObj= \t {layoutObj}")
    # Initialize lane type definitions
    lane_type_def = LaneTypeDef()

    logger.info("\n----- Distributing traffic to lanes -----")

    # Create traffic distributor and allocate vehicles to lanes
    distributor = TrafficDistributor(vphObj, layoutObj, lane_type_def)
    assigned_vph = distributor.initiateVphAllocationToLanes()
    logger.info("            ")
    logger.info("Final Assigned VPH:", assigned_vph)

    logger.info("\n----- Distributing to lanes completed -----")

    # Convert assigned VPH to traffic flow map format required by simulator
    traffic_flows_map = convert_to_traffic_flows_map(assigned_vph, layoutObj)

    logger.info("---- TRANSFORMING Payload to feed to simulator ------")
    logger.info("traffic_flows_map:", traffic_flows_map)
    logger.info("----- TRAFFIC FLOW MAPS GENERATED | Starting Simulation-----\n")

    # Start the actual simulation with the prepared data
    layout_results = startSimulation(traffic_flows_map, vphObj, layoutObj)
    logger.info("\n----- SIMULATION RESULTS -----")
    logger.info(f"simulation_results = {layout_results}")
    logger.info("\n-----------------------")
    return layout_results


def workflow(jid, jlid):
    """
    Execute the complete simulation workflow including state management.

    Args:
        jid (int): Job ID
        jlid (int): Job Layout ID

    Returns:
        str: "success" if workflow completes successfully, None otherwise
    """
    logger.info(f" workflow() ")
    try:
        # Update job state to indicate simulation has started
        changeLayoutState(
            jid, jlid, JLJobStates.JOB_ACCEPTED_BY_SIM
        )  # changing the job state to 'Accepted' by simulator
        logger.info("job for jid = {jid} and jlid = {jlid} accepted ")

        logger.info("------- EXECUTING SIMULATOR NOW --- ")
        # Run the simulation
        layout_results = executeSimulator(jid, jlid)

        # Store simulation results in database
        storeSimulationResults(jlid, layout_results)
        logger.info("------- SIMULATION RESULTS STORED --- ")

        # Update job state to completed
        changeLayoutState(
            jid, jlid, JLJobStates.JOB_COMPLETED
        )  # changing the job state to 'Completed' by simulator
        logger.info("changed job status for jlid")
        return "success"
    except Exception as e:
        # Handle any exceptions during simulation
        msg = f"Simulation for this jid {jid} and jlid {jlid} failed: {str(e)}"
        logger.error(msg)

        # Store error information in database
        storeSimulationResults(
            jlid,
            {
                "status": f"Simulation for this jid {jid} and jlid {jlid} failed: {str(e)}"
            },
        )

        # Update job state to failed
        changeLayoutState(
            jid, jlid, JLJobStates.JOB_FAILED
        )  # changing the job state to 'Failed' by simulator

        return None


def triggerSimulatorWorkflow():
    """
    Entry point function to trigger the simulation workflow.
    Expects command line arguments for job ID and job layout ID.

    Returns:
        str: Result message or error message
    """
    logger.info("triggerSimulatorWorkflow() ")

    # Validate command line arguments
    if len(sys.argv) != 3:
        logger.error("Usage: python simulator.py <jid> <jlid>")
    else:
        try:
            # Parse job ID and job layout ID from command line arguments
            jid = int(sys.argv[1])
            jlid = int(sys.argv[2])

            # Execute the workflow
            result = workflow(jid, jlid)
            if result is None:
                raise ValueError("Exception Occured")
            else:
                return result
        except Exception as e:
            # Handle any exceptions during workflow execution
            msg = f"Simulation for this jid {jid} and jlid {jlid} failed: {str(e)}"
            logger.error(msg)
            return msg


# Script entry point
if __name__ == "__main__":
    logger.info("triggering triggerSimulatorWorkflow() ")
    # Start the simulation workflow
    triggerSimulatorWorkflow()
    logger.info("completed triggerSimulatorWorkflow() ")
