import json
from typing import List, NamedTuple
from dataclasses import dataclass
from enum import Enum, auto
from mapperVPHObject import VPHData
from mapperLayoutObject import JunctionLayout, LaneType, LaneMap, Arm
from db.connectionManager import getDbConnection

from simulatorCore.conf.logConfig import get_logger
from db.dbOperations import JLJobStates, readJobPayloads

logger = get_logger(__name__)


class IngestionManager:
    """
    Manages the ingestion of input data from the database and transforms it into object models.
    """

    def ingestInputs(self, jid, jlid):
        logger.info(f"ingestInputs()")
        # pull data from the database
        vph_data, jlayout_data = readJobPayloads(jid, jlid)

        # modify the lane types in layout data to expected format 'busLane' => 'bus'
        modified_jlayout_data = modify_lane_types(jlayout_data)

        # transform json to objects
        vphObj = VPHData.vphJsonToObj(vph_data)
        # layoutObj = JunctionLayout.layoutJsonToObj(jlayout_data)
        layoutObj = JunctionLayout.layoutJsonToObj(modified_jlayout_data)

        return vphObj, layoutObj


""" Convenience function that creates an IngestionManager instance and calls its ingestInputs method. """


def readVphLayoutDataFromDb(jid, jlid):
    logger.info(f"readVphLayoutDataFromDb()")
    im = IngestionManager()
    return im.ingestInputs(jid, jlid)


"""     Transforms lane type identifiers in the layout data to match expected formats. """


def modify_lane_types(data):
    # Define the replacements
    replacements = {"busLane": "bus", "cycleLane": "cycle"}

    # Recursively replace the lane types
    def replace_lane_types(data):
        if isinstance(data, dict):
            # If it's a dictionary, check each key-value pair
            for key, value in data.items():
                if isinstance(value, str) and value in replacements:
                    # Replace the value if it's a string and matches a replacement key
                    data[key] = replacements[value]
                else:
                    # Otherwise, recursively process the value
                    replace_lane_types(value)
        elif isinstance(data, list):
            # If it's a list, recursively process each item
            for item in data:
                replace_lane_types(item)

    # Call the nested function to modify the data in-place
    replace_lane_types(data)

    # Return the modified data

    return data
