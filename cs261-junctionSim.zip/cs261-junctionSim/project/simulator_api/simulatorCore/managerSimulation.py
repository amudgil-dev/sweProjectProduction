import simpy  # Discrete-event simulation library
from enum import Enum
import collections
import random
from collections import namedtuple
from abc import ABC, abstractmethod
import json

from simulatorCore.conf.logConfig import (
    get_logger,
    setup_logging,
)  # Logging configuration

# Initialize logger for this module
setup_logging()
logger = get_logger(__name__)

# Named tuple to store car information and its arrival time
CarRecord = namedtuple("CarRecord", ["car", "arrivalTime"])

# Local variables and counters
lastPedCrossing = 0  # Tracks when the last pedestrian crossing occurred
pedReq = False  # Flag for pedestrian crossing request

# From layout configuration
pedCrossing = False  # Whether pedestrian crossing is enabled

# From Vehicles Per Hour configuration
pedcrph = 10  # Pedestrian crossing requests per hour
pedCrossingDur = 10  # Duration of pedestrian crossing in seconds


def initialisePedVars(vphObj, layoutObj):
    """Initialize pedestrian-related variables from configuration objects"""
    print("initialisePedVars()")
    global pedCrossing, pedcrph, pedCrossingDur
    pedCrossing = layoutObj.pedFlag  # Enable/disable pedestrian crossing
    pedcrph = vphObj.pedRq  # Set pedestrian request rate
    pedCrossingDur = vphObj.pedDur  # Set pedestrian crossing duration


# Abstract base class for light control strategies
class LightControlStrategy(ABC):
    @abstractmethod
    def run_lights(self, env, light_control):
        """Abstract method to be implemented by concrete strategies"""
        pass


# Concrete strategy implementations for different traffic light control scenarios
class DefaultLightStrategy(LightControlStrategy):
    def run_lights(self):
        pass


class PedestrianLightStrategy(LightControlStrategy):
    def run_lights(self):
        pass


class SpecialLaneLightStrategy(LightControlStrategy):
    def run_lights(self):
        pass


class RightFilterLightStrategy(LightControlStrategy):
    def run_lights(self):
        pass


class LightControl:
    """Controls traffic light phases and timing"""

    def __init__(self, env):
        logger.info(f"-------------- initialised LightControl -----------")
        self.env = env  # SimPy environment
        self.phaseCount = 0  # Counter for light phases

        # Subscriber lists for different light states and directions
        self.red_ns_subs = []  # North-South red light subscribers
        self.red_nsSpecial_subs = []  # North-South special lane red light subscribers
        self.red_ew_subs = []  # East-West red light subscribers
        self.red_ewSpecial_subs = []  # East-West special lane red light subscribers
        self.green_ns_subs = []  # North-South green light subscribers
        self.green_nsSpecial_subs = (
            []
        )  # North-South special lane green light subscribers
        self.green_ew_subs = []  # East-West green light subscribers
        self.green_ewSpecial_subs = []  # East-West special lane green light subscribers

        # Start the traffic light control process
        self.env.process(self.run_lights())

        # Start pedestrian request generation if enabled
        if pedCrossing and pedcrph > 0:
            self.env.process(generatePedReq(env))

    def _broadcast(self, subscribers):
        """Notify all subscribers of a light change"""
        for callback in subscribers:
            callback()

    def run_lights(self):
        """Main traffic light control process"""
        logger.info(f"-------------- run_lights -----------")
        while True:
            self.phaseCount += 1
            global pedReq, lastPedCrossing

            # Handle pedestrian crossing if requested and enough time since last crossing
            if (
                pedCrossing
                and pedcrph > 0
                and pedReq
                and (self.phaseCount - lastPedCrossing >= 2)
            ):
                logger.info(f"{self.env.now} All red for pedestrian crossing")
                yield self.env.timeout(
                    pedCrossingDur
                )  # All lights red during pedestrian crossing
                pedReq = False
                lastPedCrossing = self.phaseCount
                logger.info(f"{self.env.now} Pedestrian crossing complete")

            logger.info("a")

            # Handle North-South special lanes (bus/cycle) if any
            if len(self.green_nsSpecial_subs) > 0:
                self._broadcast(self.green_nsSpecial_subs)
                logger.info(f"{self.env.now} ns special is green")
                yield self.env.timeout(30)  # Special lanes get 30 seconds
                self._broadcast(self.red_nsSpecial_subs)
            logger.info("b")

            # North-South regular lanes
            self._broadcast(self.green_ns_subs)
            logger.info(f"{self.env.now} ns is green")
            yield self.env.timeout(40)  # Regular lanes get 40 seconds
            self._broadcast(self.red_ns_subs)

            # Handle East-West special lanes if any
            if len(self.green_ewSpecial_subs) > 0:
                self._broadcast(self.green_ewSpecial_subs)
                logger.info(f"{self.env.now} ns special is green")
                yield self.env.timeout(30)  # Special lanes get 30 seconds
                self._broadcast(self.red_ewSpecial_subs)

            # East-West regular lanes
            self._broadcast(self.green_ew_subs)
            logger.info(f"{self.env.now} ew is green")
            yield self.env.timeout(40)  # Regular lanes get 40 seconds
            self._broadcast(self.red_ew_subs)

            # Reset phase count to prevent overflow
            if self.phaseCount > 1000:
                self.phaseCount = 0


# Enum for vehicle types
class VehicleType(Enum):
    CAR = 1
    BUS = 2
    CYCLE = 3


# Enum for lane types
class LaneType(Enum):
    LEFTONLY = 1
    RIGHTONLY = 2
    STRAIGHTONLY = 3
    LEFTSTRAIGHT = 4
    RIGHTSTRAIGHT = 5
    ALLDIRS = 6


class Lane:
    """Represents a traffic lane with queue and statistics"""

    def __init__(self, env, name, dir, vehicleType, laneType):
        logger.info("lane clase init")
        logger.info(f"-------------- initialised Lane -----------")
        self.env = env  # SimPy environment
        self.name = name  # Lane identifier
        self.dir = dir  # Direction (north, south, east, west)
        self.vehicleType = vehicleType  # Type of vehicle allowed
        self.laneType = laneType  # Type of lane (turn directions)
        self.laneQueue = collections.deque()  # Queue of vehicles
        self.green = False  # Light state

        # Time it takes for a vehicle to pass through the junction based on lane/vehicle type
        self.passingTime = {
            LaneType.LEFTONLY: 1,
            LaneType.LEFTSTRAIGHT: 1,
            LaneType.STRAIGHTONLY: 1,
            LaneType.RIGHTSTRAIGHT: 1,
            LaneType.RIGHTONLY: 1,
            VehicleType.BUS: 1,
            VehicleType.CYCLE: 1,
        }

        # Statistics tracking
        self.maxQueueLength = 0  # Maximum queue length observed
        self.maxWaitTime = 0.0  # Maximum wait time observed
        self.totalWaitTime = 0.0  # Total wait time for all vehicles
        self.carsProcessed = 0  # Number of vehicles processed

    def addCar(self, car):
        """Add a car to the lane queue"""
        self.laneQueue.append(CarRecord(car=car, arrivalTime=self.env.now))
        self.maxQueueLength = max(self.maxQueueLength, len(self.laneQueue))

    def moveCars(self):
        """Process cars from the queue when light is green"""
        while self.green and self.laneQueue:
            carData = self.laneQueue.popleft()  # Get next car from queue
            waitTime = self.env.now - carData.arrivalTime  # Calculate wait time
            self.totalWaitTime += waitTime
            self.carsProcessed += 1
            self.maxWaitTime = max(self.maxWaitTime, waitTime)
            passingTime = self.passingTime.get(
                self.laneType, 5
            )  # Get appropriate passing time
            yield self.env.timeout(
                passingTime
            )  # Simulate time to pass through junction
            logger.info(f"{self.env.now} {self.name} car has left junction")

    def green_light(self):
        """Called when light turns green"""
        self.green = True
        self.env.process(self.moveCars())  # Start processing cars

    def red_light(self):
        """Called when light turns red"""
        self.green = False


def generateCars(env, lane, delayFunction):
    """Generate cars at random intervals based on flow rate"""
    logger.info("generateCars()")

    while True:
        yield env.timeout(delayFunction())  # Wait for next car
        lane.addCar(object())  # Add car to lane


def calculateDelay(flowRate):
    """Calculate delay between car arrivals based on flow rate"""
    logger.info(f"calculating flow rate => {flowRate} ")
    return lambda: random.expovariate(
        flowRate / 3600
    )  # Convert vehicles per hour to seconds


def generatePedReq(env):
    """Generate pedestrian crossing requests at random intervals"""
    while True:
        yield env.timeout(
            random.expovariate(pedcrph / 3600)
        )  # Wait for next pedestrian
        global pedReq

        logger.info(f"pedcrph in genPeREq => {pedcrph} ")

        pedReq = True  # Set pedestrian request flag
        logger.info(f"{env.now} Pedestrian request received")


def startSimulation(traffic_flows_map, vphObj, layoutObj):
    """Main function to start the traffic simulation"""
    logger.info("in startSimulation() ")
    initialisePedVars(vphObj, layoutObj)  # Initialize pedestrian variables
    env = simpy.Environment()  # Create simulation environment
    lights = LightControl(env)  # Create traffic light controller

    logger.info(f"env =>{env}")

    lanes = {}  # Dictionary to store all lanes

    logger.info("creating lanes ")

    # Create lanes based on traffic flow configuration
    for direction, lane_data in traffic_flows_map.items():
        lanes[direction] = {}
        for lane_name, (lane_type, flow) in lane_data.items():
            full_lane_name = f"{direction}_{lane_name}"

            # Determine vehicle type based on lane type
            vehicle_type = (
                VehicleType.BUS
                if lane_type == "bus"
                else VehicleType.CYCLE if lane_type == "cycle" else VehicleType.CAR
            )

            # Convert lane type string to enum
            lane_type_enum = (
                LaneType[lane_type.upper()]
                if lane_type.upper() in LaneType.__members__
                else LaneType.STRAIGHTONLY
            )

            # Create lane object
            lane = Lane(env, full_lane_name, direction, vehicle_type, lane_type_enum)
            lanes[direction][lane_name] = lane

            # Register lane with appropriate light controller subscribers
            if direction in ["north", "south"]:
                if vehicle_type in [VehicleType.BUS, VehicleType.CYCLE]:
                    lights.green_nsSpecial_subs.append(lane.green_light)
                    lights.red_nsSpecial_subs.append(lane.red_light)
                else:
                    lights.green_ns_subs.append(lane.green_light)
                    lights.red_ns_subs.append(lane.red_light)
            else:
                if vehicle_type in [VehicleType.BUS, VehicleType.CYCLE]:
                    lights.green_ewSpecial_subs.append(lane.green_light)
                    lights.red_ewSpecial_subs.append(lane.red_light)
                else:
                    lights.green_ew_subs.append(lane.green_light)
                    lights.red_ew_subs.append(lane.red_light)

    # Start car generation processes for each lane
    for direction, lane_data in traffic_flows_map.items():
        for lane_name, (lane_type, flow) in lane_data.items():
            lane = lanes[direction][lane_name]

            logger.info(f"starting the car gen process for lane => {lane_name} ")

            env.process(generateCars(env, lane, calculateDelay(flow)))

    # Run simulation for 5 hours (18000 seconds)
    env.run(18000)

    # Log final statistics
    logger.info("\nFinal queue lengths:")
    for direction, lane_data in lanes.items():
        for lane_name, lane in lane_data.items():
            averageWaitTime = (
                lane.totalWaitTime / lane.carsProcessed if lane.carsProcessed > 0 else 0
            )
            logger.info(f"Lane {lane.name}: ({direction}, {lane_name}): ")
            logger.info(f"  Average wait time: {averageWaitTime:.2f}s")
            logger.info(f"  Maximum wait time: {lane.maxWaitTime:.2f}s")
            logger.info(f"  Maximum queue length: {lane.maxQueueLength} vehicles")

    logger.info("---------------------------------")
    logger.info("final json")
    logger.info("---------------------------------")

    # Prepare the output dictionary with simulation results
    output = {
        "status": "simulation completed successfully",
        "northArm": {"laneStats": {}},
        "eastArm": {"laneStats": {}},
        "southArm": {"laneStats": {}},
        "westArm": {"laneStats": {}},
    }

    # Populate the output dictionary with statistics for each lane
    for direction, lane_data in lanes.items():
        arm_name = direction if direction.endswith("Arm") else f"{direction}Arm"
        for lane_name, lane in lane_data.items():
            average_wait_time = (
                lane.totalWaitTime / lane.carsProcessed if lane.carsProcessed > 0 else 0
            )
            output[arm_name]["laneStats"][lane_name] = {
                "average wait time": round(average_wait_time, 2),
                "max wait time": round(lane.maxWaitTime, 2),
                "max queue length": lane.maxQueueLength,
            }

    # Log final output as JSON
    logger.info(json.dumps(output, indent=4))
    return output


# Example traffic flow configuration (commented out)
# traffic_flows_map = {
#     "northArm": {
#         "lane1": ("bus", 30),
#         "lane2": ("leftOnly", 45),
#         "lane3": ("rightOnly", 90),
#         "lane4": ("straightOnly", 135),
#     },
#     "eastArm": {
#         "lane1": ("leftStraight", 32),
#         "lane2": ("rightStraight", 32),
#         "lane3": ("straightOnly", 35),
#     },
#     "southArm": {"lane1": ("leftOnly", 25), "lane2": ("rightStraight", 75)},
#     "westArm": {
#         "lane1": ("leftOnly", 50),
#         "lane2": ("rightOnly", 50),
#         "lane3": ("straightOnly", 100),
#     },
# }

# startSimulation(traffic_flows_map)
