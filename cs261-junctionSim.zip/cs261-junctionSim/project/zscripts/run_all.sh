# This runs only one container of each component 
docker compose up --build -d 
