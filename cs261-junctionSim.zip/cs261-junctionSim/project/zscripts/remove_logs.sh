# Find the log files to be deleted

echo "------------------------------"
echo " Finding the log files"
echo "------------------------------"
find logs -type f -name "*.log"

echo "------------------------------"
echo " deleting the above log files"
echo "------------------------------"
find logs -type f -name "*.log" -delete
