# This runs only multiple containers of each component as specified in the command

docker compose up -d --scale ui_app=3 --scale simulator_api=2 --scale test_app=1

