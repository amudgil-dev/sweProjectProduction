# This forces the rebuild without caching and also starts the container
docker compose build --no-cache simulator_api
docker compose up -d --no-deps --force-recreate simulator_api
