# This forces the rebuild without caching and also starts the container

docker compose build --no-cache test_app
docker compose up -d --no-deps --force-recreate test_app