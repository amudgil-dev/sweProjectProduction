# This builds all the components but does not run it 

docker compose build 

