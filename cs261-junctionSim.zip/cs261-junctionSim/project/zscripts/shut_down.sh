# shut down the containers
docker compose down

