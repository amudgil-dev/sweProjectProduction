
DROP TABLE IF EXISTS simulation_results cascade;
DROP TABLE IF EXISTS junction_layouts cascade;
DROP TABLE IF EXISTS junction_states cascade;
DROP TABLE IF EXISTS junction_layout_states cascade;
DROP TABLE IF EXISTS junctions cascade;
DROP TABLE IF EXISTS users cascade;

SELECT 'Tables dropped successfully';


-- Create users table
CREATE TABLE users (
    UID SERIAL PRIMARY KEY,
    Username VARCHAR(100) UNIQUE NOT NULL,
    UserPass VARCHAR(100) DEFAULT NULL
);

-- Create junction_states table
CREATE TABLE junction_states (
    JStateID SERIAL PRIMARY KEY,
    JStateName VARCHAR(50) NOT NULL,
    JStateDescription VARCHAR(255)
);

-- Create junction_layout_states table
CREATE TABLE junction_layout_states (
    JLStateID SERIAL PRIMARY KEY,
    JLStateName VARCHAR(50) NOT NULL,
    JLStateDescription VARCHAR(255)
);

-- Create junctions table
CREATE TABLE junctions (
    JID SERIAL PRIMARY KEY,
    UID INTEGER NOT NULL REFERENCES users(UID) ON DELETE CASCADE ON UPDATE CASCADE,
    JName VARCHAR(50),
    VPHObject JSONB NOT NULL,
    JStateID INTEGER NOT NULL REFERENCES junction_states(JStateID) ON DELETE CASCADE ON UPDATE CASCADE,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    LastUpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create junction_layouts table
CREATE TABLE junction_layouts (
    JLID SERIAL PRIMARY KEY,
    JID INTEGER NOT NULL REFERENCES junctions(JID) ON DELETE CASCADE ON UPDATE CASCADE,
    JLName VARCHAR(50),
    ConfigurationObject JSONB NOT NULL,
    JLStateID INTEGER NOT NULL REFERENCES junction_layout_states(JLStateID) ON DELETE CASCADE ON UPDATE CASCADE,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    LastUpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP    
);

-- Create simulation_results table
CREATE TABLE simulation_results (
    SID SERIAL PRIMARY KEY,
    JLID INTEGER NOT NULL REFERENCES junction_layouts(JLID) ON DELETE CASCADE ON UPDATE CASCADE,
    ResultsObject JSONB NOT NULL,
    CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    LastUpdatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

SELECT 'Tables created successfully';

-- Creating Triggers, Procedures and Functions 
/*
    Keeps the LastUpdatedAt columns updated
*/
CREATE OR REPLACE FUNCTION update_lastUpdatedAt() RETURNS TRIGGER
AS $$
    BEGIN
        NEW.LastUpdatedAt = CURRENT_TIMESTAMP;
        RETURN NEW;
    END;
$$ LANGUAGE plpgsql;

/*
    Triggers to automatically maintain the lastUpdatedAt columns
*/
DROP TRIGGER IF EXISTS updated_junction ON junctions;
CREATE TRIGGER updated_junction BEFORE UPDATE ON junctions -- For junctions
FOR EACH ROW
EXECUTE FUNCTION update_lastUpdatedAt();

DROP TRIGGER IF EXISTS updated_junction_layout ON junction_layouts;
CREATE TRIGGER updated_junction_layout BEFORE UPDATE ON junction_layouts -- For junction_layouts
FOR EACH ROW
EXECUTE FUNCTION update_lastUpdatedAt();


-- Updates the state of a junction to finished if all of its layouts have finished simulating
CREATE OR REPLACE FUNCTION finished_simulation() RETURNS TRIGGER
AS $$
    DECLARE
        all_finished BOOLEAN;
    BEGIN
        -- If the jlstateid is changed to 5 for a layut (meaning it failed), then marking the entire junction to be failed.
            -- As the likely reason of failure is data discrepancy.
        IF NEW.JLStateID = 5 THEN -- if failure
            UPDATE junctions
            SET JStateID = 5 -- mark the junction state to be failed
            WHERE JID = NEW.JID;
        END IF;

        IF NEW.JLStateID = 4 THEN -- if successful simulation

        -- Check if all layouts for this junction are finished
            SELECT NOT EXISTS (
                SELECT 1
                FROM junction_layouts AS jl
                WHERE JID = NEW.JID
                AND JLStateID <> 4 -- Check if the layouts are all successful for this and 
            ) INTO all_finished; -- all_finished will be true if all junction layouts have state 'Finished'

            -- If all layouts are finished, update the junction's state to reflect that
            IF all_finished THEN
                UPDATE junctions
                SET JStateID = 4 -- completed successfully
                WHERE JID = NEW.JID;
            END IF;
        END IF;

        RETURN NEW;
    END;
$$ LANGUAGE plpgsql;

-- If all layouts created for a certain junction have finished simulating, mark the junction's state as 'Finished'
CREATE TRIGGER finished_simulation AFTER UPDATE ON junction_layouts
FOR EACH ROW
-- WHEN (NEW.JLStateID = 4)
EXECUTE FUNCTION finished_simulation();

SELECT 'Triggesrs created successfully';

-- Insert into users table
INSERT INTO users (Username, UserPass) VALUES
('user1@gmail.com', 'secured'),
('user2@gmail.com', 'secured'),
('user3@gmail.com', 'secured');

SELECT 'User records inserted successfully';

-- Insert into junction_states table
INSERT INTO junction_states (JStateName, JStateDescription) VALUES
('New', 'New Junction Captured, its layout details may or may not have been captured'),
('Not Started', 'No layouts for this junction have started simulating'),
('In Process', 'The layouts for this junction are currently being simulated'),
('Completed',  'All of the layouts for this junctions have finished simulating'),
('Failed', 'Simulation of one or more layout resulted in error ');

SELECT 'junction_states records inserted successfully';

-- Insert into junction_layout_states table
INSERT INTO junction_layout_states (JLStateName, JLStateDescription) VALUES
('NewJob', 'New junction layout job'),
('Triggered', 'Job is passed to similator'),
('Accepted', 'Accepted by Simulator '),
('Completed', 'Simulation completed'),
('Failed', 'Simulation job failed');

SELECT 'junction_layout_states records inserted successfully';

-- Insert into junctions table
INSERT INTO junctions (UID, JName, VPHObject, JStateID) VALUES
(1, 'Junction A', '{"type": "T-junction", "lanes": 3}', 1),
(2, 'Junction B', '{"type": "Roundabout", "lanes": 4}', 2),
(3, 'Junction C', '{"type": "Crossroads", "lanes": 4}', 3);

SELECT 'junctions records inserted successfully';

-- Insert into junction_layouts table
INSERT INTO junction_layouts (JID,JLName, ConfigurationObject, JLStateID) VALUES
(1,'l1', '{"layout": "T-shape", "signals": 3}', 1),
(1,'l2', '{"layout": "Circular", "signals": 4}', 1),
(1,'l3', '{"layout": "Cross", "signals": 5}', 1),
(2,'l4', '{"layout": "T-shape", "signals": 3}', 1),
(3,'l1', '{"layout": "Circular", "signals": 4}', 2),
(2,'l2','{"layout": "Cross", "signals": 4}', 3);

SELECT 'junction_layouts records inserted successfully';

-- Insert into simulation_results table
INSERT INTO simulation_results (JLID, ResultsObject) VALUES
(1, '{"average_wait_time": 45, "throughput": 500}'),
(2, '{"average_wait_time": 30, "throughput": 750}'),
(3, '{"average_wait_time": 60, "throughput": 400}');

SELECT 'simulation_results records inserted successfully';

commit;


select count(*) from users;
select count(*) from junction_layout_states;
select count(*) from junction_states;
select count(*) from junctions;
select count(*) from junction_layouts;
select count(*) from simulation_results;
